$(document).ready(function(){
 $(".popup .content-pop .choose-size li ,.navbar-nav li").click(function(){
   $(this).addClass("active").siblings().removeClass("active");
  });
    
$(".popup .content-pop .choose-kind li").click(function(){
    $(this).addClass("active");
    $(this).click(function(){
        $(this).removeClass("active");
    });
});
});

//owl carousle
$('#index-caro').owlCarousel({
    rtl:true,
    loop:true,
    margin:10,
    nav:false,
    dots: false,
    autoplay:true,
    autoplayTimeout:3000,
    stagePadding:80,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:5
        }
    }
})
//nav
$(document).ready(function(){
 $(".navbar-inverse .navbar-toggle").click(function(){
  $("#myCarousel a").toggle();

});

});


//turnon-off button

//$(document).ready(function(){
//   $('.btn-toggle span').click(function(){
//   $( ".btn-toggle .handle " ).empty();
//   $(this).clone().appendTo( ".btn-toggle .handle" );
//   $(".login form ,.main-heading h6").toggle();
//
//});
//});

$(document).ready(function(){
   $('.btn-toggle span').click(function(){
     $(".main-heading h6").toggle();
       $(".handle span").toggle();
    });
    $(".handle ,.handle span").click(function(){
        $(".handle span").toggle();
         $(".main-heading h6").toggle();
    });
});


//count-numbers



$(document).ready(function(){
            $('.pp').click(function(){
                var x=$(this).parent().find(".cc").val()
                   x++;
                $(this).parent().find(".cc").val(x)
            });

            $('.mm').click(function(){
                var x=$(this).parent().find(".cc").val()
                  if(x>1){
                 x--;
                }
               $(this).parent().find(".cc").val(x)
            });
    });

//         
//   
      //nice-scroll
$(document).ready(function(){
    $(".nicescroll-box").niceScroll(".wrap",{cursorcolor:"#616161",cursorwidth:"8px",background:"rgba(97,97,97,0.5)",cursorborder:"1px solid #afafaf",autohidemode:'leave'});
    
//close in menu
    $(".remove-mu").click(function(){
        $(this).parent().parent().remove();
    });
    //close popup
//    $(".overlay").click(function(){
//        $(this).css("display","none");
//    });
});
//scroll
$(document).ready(function(){
  $('.navbar-inverse .navbar-nav>li>a.we').click (function(){
      $('html,body').animate({
          scrollTop:$("#about-para").offset().top},1000);
});
  $('.navbar-inverse .navbar-nav>li>a.call').click (function(){
      $('html,body').animate({
          scrollTop:$("#footer").offset().top},3000);
});
  $('.navbar-inverse .navbar-nav>li>a.photo').click (function(){
      $('html,body').animate({
          scrollTop:$("#owl-caro").offset().top},1500);
}); 
 $('.navbar-inverse .navbar-nav>li>a.menmen').click (function(){
      $('html,body').animate({
          scrollTop:$("#menu11").offset().top},1500);
});
//scroll background color of navbar
      $(window).scroll(function() {
       		var scrollVal = $(this).scrollTop();
        	if ( scrollVal > 250) {
            	
            	$('.navbar-inverse').css({'background-color':'#222'});
        	}
              else{
                  
            	$('.navbar-inverse').css({'background-color':'transparent'});
              }
        	
    	});
//    $('.navbar-nav li a').click(function(){
//        $('#myNavbar').hide();
//    });
//    $('.navbar-header button').click(function(){
//        $('#myNavbar').toggle().css("height","auto");
//    });
    
//    $('.btn-toggle.active > .handle').click(function(){
//        $(this).prop('disabled', true);
//    });
});